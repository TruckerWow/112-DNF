Description: 
This game is similar to the arcade version of the combat game. The player needs to protect the base under the attack of the enemy wave after wave, once the base is destroyed by the enemy, the game fails.

Run tp3.py in the code folder to start the game.

The goal is to protect the base here from being destroyed by enemies, and enemies will occur randomly from both sides. They will automatically trace and attack the player. The player will fall to the ground and his health point also decreases when getting attacked. And this red ball represents the player's health point.

The player has four methods to attack the enemy. The first one is normal attack by pressing 'x', which costs nothing. And the skill bar contains three skills. we need to consume magic point to use skills and the blue ball represents the player's magic point. We could press 'a' to use first skill and attack enemies around the player; press 's' to launch a magic ball in a straight line; and press 'd' to attack all enemies present. When we kill the enemies, some coins will occur there, and we need to get close to collect the coins.

If the player is killed by enemies, it needs 5 seconds to revive the player. During this period, enemies will continue to attack the base, and the base will automatically attack enemies within a certain range. Also, if the base is destroyed, the game is over. The red bars above enemies and the base represent their health point.

We could also press 'b' to open the store, and use coins to buy medicine in this store. After buying that, we could use red medicine to restore health point by pressing '1' or use blue one to restore magic point by pressing '2'.

Press 'm' to open property panel, here we could see all properties of the player, the score and the attack value could be increased by killing enemies.

At the left-top corner is a game timer, when the time is up, we could get into next level.

In level 2, we could control two characters. The enemy is always flying in the sky, and randomly attack players at long range. So the players has to predict the position of the enemy and use parabola to throw the explosive to attack the enemy and adjust the throw angle by pressing 'up''down' or 'w' 's'. 

Also, the players could use skill by pressing 'f' to freeze the enemy. 

When we kill this enemy, we win.